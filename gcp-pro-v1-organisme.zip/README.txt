GCP PRO V1 - ORGANISME

Cette version contient :
- formulaire de contrôle ménage ;
- conforme / non conforme par zone ;
- note automatique sur 20 ;
- commentaire obligatoire si non conforme ;
- photo obligatoire en cas de non-conformité ;
- historique local ;
- tableau responsable local ;
- préparation du mail prestataire en cas de reprise ;
- mode hors réseau local.

Limite V1 :
Le mail n'est pas encore envoyé automatiquement par un serveur.
Le bouton prépare le mail dans l'application Mail.
La V2 ajoutera une base de données et un vrai envoi automatique.
