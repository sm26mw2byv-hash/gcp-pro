const criteria=[
  {name:"Hall d’entrée", points:4},
  {name:"Escaliers", points:3},
  {name:"Ascenseur", points:2},
  {name:"Local poubelles", points:4},
  {name:"Vitrerie", points:2},
  {name:"Extérieurs", points:3},
  {name:"Finitions", points:2}
];
let photos=[];

function go(id){
  document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
  if(id==='history') renderHistory();
  if(id==='dashboard') renderDashboard();
  scrollTo(0,0);
}
function updateNetwork(){
  document.getElementById('network').textContent=navigator.onLine?'En ligne':'Hors réseau';
}
addEventListener('online',updateNetwork);
addEventListener('offline',updateNetwork);

function initZones(){
  const el=document.getElementById('zones');
  el.innerHTML=criteria.map((c,i)=>`
    <div class="zone">
      <div class="zoneHead"><b>${c.name}</b><span class="points">/${c.points}</span></div>
      <div class="choice">
        <label><input type="radio" name="status_${i}" value="Conforme" checked onchange="calc()"> Conforme</label>
        <label><input type="radio" name="status_${i}" value="Non conforme" onchange="calc()"> Non conforme</label>
      </div>
      <textarea name="comment_${i}" rows="2" placeholder="Commentaire si non conforme"></textarea>
    </div>
  `).join('');
  calc();
}
function calc(){
  let total=0;
  criteria.forEach((c,i)=>{
    const value=document.querySelector(`input[name="status_${i}"]:checked`)?.value;
    if(value==="Conforme") total+=c.points;
  });
  document.getElementById('total').textContent=total;
  const verdict=document.getElementById('verdict');
  verdict.textContent= total===20?'Conforme': total>=15?'Reprise partielle': total>=10?'Reprise demandée':'Non conforme';
}

document.getElementById('photos').addEventListener('change',async e=>{
  photos=[];
  document.getElementById('preview').innerHTML='';
  for(const f of e.target.files){
    const data=await toData(f);
    photos.push({name:f.name,data});
    const img=document.createElement('img');
    img.src=data;
    document.getElementById('preview').appendChild(img);
  }
});
function toData(file){
  return new Promise(r=>{
    const fr=new FileReader();
    fr.onload=()=>r(fr.result);
    fr.readAsDataURL(file);
  });
}

document.getElementById('form').addEventListener('submit',e=>{
  e.preventDefault();
  const fd=new FormData(e.target);
  const details=criteria.map((c,i)=>({
    zone:c.name,
    points:c.points,
    statut:fd.get('status_'+i),
    commentaire:fd.get('comment_'+i) || ""
  }));
  const nonConformes=details.filter(d=>d.statut==="Non conforme");

  for(const d of nonConformes){
    if(!d.commentaire.trim()){
      alert("Commentaire obligatoire pour la zone non conforme : " + d.zone);
      return;
    }
  }
  if(nonConformes.length && photos.length===0){
    alert("Au moins une photo est obligatoire en cas de non-conformité.");
    return;
  }

  const total=Number(document.getElementById('total').textContent);
  const control={
    id:Date.now(),
    date:new Date().toLocaleString('fr-FR'),
    pending:!navigator.onLine,
    gcp:fd.get('gcp'),
    lot:fd.get('lot'),
    residence:fd.get('residence'),
    adresse:fd.get('adresse'),
    entreprise:fd.get('entreprise'),
    emailPrestataire:fd.get('emailPrestataire'),
    commentaire:fd.get('commentaire'),
    signature:fd.get('signature'),
    total,
    verdict:document.getElementById('verdict').textContent,
    details,
    photosCount:photos.length
  };

  const all=getAll();
  all.unshift(control);
  localStorage.setItem('gcpProControlsV1',JSON.stringify(all));
  showResult(control);

  e.target.reset();
  photos=[];
  document.getElementById('preview').innerHTML='';
  initZones();
});

function showResult(c){
  const nc=c.details.filter(d=>d.statut==="Non conforme");
  const result=document.getElementById('result');
  let text=`Contrôle enregistré\n\nRésidence : ${c.residence}\nNote : ${c.total}/20 — ${c.verdict}\n`;
  if(nc.length){
    text+=`\nReprise demandée au prestataire : ${c.entreprise}\nZones non conformes :\n`;
    text+=nc.map(d=>`- ${d.zone} : ${d.commentaire}`).join("\n");
  } else {
    text+=`\nAucune reprise demandée.`;
  }

  const subject=encodeURIComponent(`Contrôle ménage - ${c.residence} - Reprise demandée`);
  const body=encodeURIComponent(`Bonjour,

Lors du contrôle ménage réalisé le ${c.date}, les points suivants ont été déclarés non conformes sur la résidence ${c.residence}, ${c.adresse} :

${nc.map(d=>`- ${d.zone} : ${d.commentaire}`).join("\n")}

Note obtenue : ${c.total}/20
Statut : ${c.verdict}

Merci d'effectuer une reprise et de nous confirmer sa réalisation.
En cas de refus, merci d'indiquer le motif du refus.

Cordialement`);
  const mail=nc.length && c.emailPrestataire ? `<a href="mailto:${c.emailPrestataire}?subject=${subject}&body=${body}">Préparer le mail prestataire</a>` : "";
  result.innerHTML=text + mail;
  result.classList.remove('hidden');
}
function getAll(){
  return JSON.parse(localStorage.getItem('gcpProControlsV1')||'[]');
}
function badge(c){
  return c.total===20?'ok':c.total>=15?'warn':'bad';
}
function renderHistory(){
  const all=getAll();
  document.getElementById('historyList').innerHTML=all.length?all.map(c=>`
    <div class="item">
      <b>${c.residence}</b><br>${c.date} — ${c.gcp}<br>
      <span class="badge ${badge(c)}">${c.total}/20 — ${c.verdict}</span>
      ${c.pending?'<span class="badge warn">Hors réseau</span>':''}
      <p>${c.commentaire||''}</p>
    </div>
  `).join(''):'<p>Aucun contrôle.</p>';
}
function renderDashboard(){
  const all=getAll();
  const avg=all.length?(all.reduce((a,c)=>a+c.total,0)/all.length).toFixed(1):0;
  const reprise=all.filter(c=>c.total<20).length;
  const nc=all.filter(c=>c.total<10).length;
  document.getElementById('sTotal').textContent=all.length;
  document.getElementById('sAvg').textContent=avg;
  document.getElementById('sReprise').textContent=reprise;
  document.getElementById('sNC').textContent=nc;
  document.getElementById('dashList').innerHTML=all.map(c=>`
    <div class="item">
      <b>${c.lot}</b> — ${c.residence}<br>
      <span class="badge ${badge(c)}">${c.total}/20</span> ${c.entreprise||''}
    </div>
  `).join('')||'<p>Aucune donnée.</p>';
}
function clearAll(){
  if(confirm('Effacer tous les contrôles enregistrés sur cet appareil ?')){
    localStorage.removeItem('gcpProControlsV1');
    renderHistory();
    renderDashboard();
  }
}
if('serviceWorker' in navigator){
  navigator.serviceWorker.register('sw.js').catch(()=>{});
}
updateNetwork();
initZones();
